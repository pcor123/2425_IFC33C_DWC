

switch (key) {
    case value:
        console.log(a)
        break;

    default:
        console.log(a)
        break;
}

